<!-- Start: CTA Are Section -->        
<section class="section cta-area bg">
    <div class="container"> 
        <div class="row justify-content-center align-items-center">
            <div class="col-md-8"> 
                <div class="cta-content text-center py-3">
                    <h2 class="pb-2">GET EXPERT TRAINING</h2>
                    <p class="pb-2">Expand your knowledge and gain new skills and become <br>
                    an expert with concept pro training</p>
                    <a href="#" class="btn btn-outline-default text-white text-uppercase">START TODAY</a>
                </div>
            </div> 
        </div>  
    </div>
</section>
<!-- End: CTA Are Section -->