<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SiteSolutionSection extends Model
{
    protected $fillable = [
        'heading','content','image'
    ];
}
